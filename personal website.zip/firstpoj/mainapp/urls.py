from django.urls import path,include
from . import views
urlpatterns = [

    path('',views.HomeView.as_view(),name="home"),
    path('about/',views.AboutView.as_view(),name="about"),
    path('blog/',views.BlogView.as_view(),name="blog"),
    path('portfolio/',views.PortfollioView.as_view(),name="portfolio") ,
    path('show/', views.ShowView.as_view(), name="show"),
    path('contract/', views.ContractView.as_view(), name="contract"),
]
