from django.views.generic import TemplateView
from django.views.generic import ListView
from .models import Quotes, Post
from . models import QuoeteCatagory

class HomeView(TemplateView):
    template_name = "index.html"




class AboutView(TemplateView):
    template_name = "about.html"


class PortfollioView(TemplateView):
    template_name = "portfollio.html"


class BlogView(ListView):
    template_name = "blog.html"
    model = Post

    def get_queryset(self):
        query_set=super().get_queryset()
        return query_set


class ContractView(TemplateView):
    template_name = "contract.html"


class ShowView(ListView):
    template_name = "show.html"
    model = Quotes

    def get_queryset(self):
        query_set=super().get_queryset()
        return query_set.select_related
        ('quoate_catagory')
