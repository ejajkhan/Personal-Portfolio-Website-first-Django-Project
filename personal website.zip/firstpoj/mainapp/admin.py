from django.contrib import admin
from  . models import  QuoeteCatagory
from  . models import Quotes
from . models import Post
admin.site.register(QuoeteCatagory)
admin.site.register(Quotes)
admin.site.register(Post)
# Register your models here.
